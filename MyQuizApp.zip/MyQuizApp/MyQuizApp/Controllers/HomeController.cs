﻿using MyQuizApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyQuizApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult QuestionsStart(string Quizid)
        {
            char[] separator = { '-' };
            string[] words = Quizid.Split(separator);
            int quizLevelId = Convert.ToInt32(words[0]);
            int quesid = Convert.ToInt32(words[1]);
            ViewBag.QlvlID = quizLevelId + "-" + quesid;

            if (quizLevelId==1)
            {
                ViewBag.QlevelText = "Beginner Level";
            }
            if (quizLevelId == 2)
            {
                ViewBag.QlevelText = "Intermediate Level";
            }
            if (quizLevelId == 3)
            {
                ViewBag.QlevelText = "Advanced Level";
            }
           
            return View();
        }
        
        public ActionResult Quizlevel(string Quizid)
        {
        
            char[] separator = { '-' };
            string[] words = Quizid.Split(separator);
            
            int quizLevelId = Convert.ToInt32(words[0]);
            int quesid = Convert.ToInt32(words[1]);
            
            QuizEntities ctx = new QuizEntities();
            QuestionMaster question = ctx.QuestionMasters.Where(x => x.QLevelId == quizLevelId && x.QuestionId == quesid).FirstOrDefault();
            return Json(question, JsonRequestBehavior.AllowGet);
        }

        public ActionResult MyResult(string AnswerString, string Qlevel)
        {
            char[] separator1 = { '-' };
            string[] words1 = Qlevel.Split(separator1);
            int quizLevelId = Convert.ToInt32(words1[0]);

            string ansStr = AnswerString.Trim();
            char[] separator2 = { ',' };
            string[] words2 = ansStr.Split(separator2);

            QuizEntities ctx = new QuizEntities();
            List<QuestionMaster> questionList = ctx.QuestionMasters.Where(x => x.QLevelId == quizLevelId ).ToList();
            List<VM_MyResult> resList = new List<VM_MyResult>();
            int i = 1;
            int correctAnswer = 0;
            foreach (var qitem in questionList)
            {
                VM_MyResult resObj = new VM_MyResult(); 
                   if(qitem.Answer==Convert.ToInt32(words2[i]))
                   {
                       resObj.QuestionID = (int)qitem.QuestionId;
                       resObj.QuestionResult = "Right";
                       resList.Add(resObj);
                       correctAnswer = correctAnswer + 1;
                   }
                   else
                   {
                       resObj.QuestionID = (int)qitem.QuestionId;
                       resObj.QuestionResult = "Wrong";
                       resList.Add(resObj);
                   }

                
            }
            ViewBag.CorrectAns = correctAnswer;
            return View(resList);
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }
        public ActionResult ListAllQuestions()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}